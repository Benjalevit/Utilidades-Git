#!/usr/bin/env bash
#  Lab Canary — Script de apoyo para AWS Learner Lab (AWS CLI)
#  Arquitectura de Sistemas · UDD
#  Automatiza los comandos del laboratorio. En Learner Lab el rol de ejecución
#  ya existe: se llama 'LabRole'. NO se crean roles nuevos.
#
#  Uso:
#     bash aws_lab.sh crear         # crea la función y su API HTTP
#     bash aws_lab.sh publicar-v1   # publica la Versión 1 (estándar)
#     bash aws_lab.sh publicar-v2   # sube el código v2 (con fallos) y publica la Versión 2
#     bash aws_lab.sh canary 10     # alias 'live' con 10% de tráfico a v2 (canario)
#     bash aws_lab.sh canary 50     # sube el canario a 50%
#     bash aws_lab.sh promover      # 100% a v2 (promoción)
#     bash aws_lab.sh revertir      # 100% a v1 (rollback)
#     bash aws_lab.sh estado        # muestra el reparto actual del alias
#     bash aws_lab.sh url           # imprime la URL del endpoint
#     bash aws_lab.sh limpiar       # borra función y API
#
#  Requisitos: AWS CLI v2 configurada con las credenciales del Learner Lab.
#  Región por defecto: us-east-1 (cámbiala con la variable REGION si hace falta).


set -euo pipefail

FUNC="lab-canary"
ALIAS="live"
REGION="${REGION:-us-east-1}"
RUNTIME="nodejs22.x"
# En AWS Learner Lab el rol preexistente es LabRole.
ROLE_NAME="${ROLE_NAME:-LabRole}"

ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
ROLE_ARN="arn:aws:iam::${ACCOUNT_ID}:role/${ROLE_NAME}"

empaquetar() {
  # $1 = archivo handler a empaquetar (handler.js o handler_v2.js renombrado a handler.js)
  rm -f funcion.zip
  cp "$1" handler.js
  zip -q funcion.zip handler.js
}

case "${1:-}" in

  crear)
    echo ">> Empaquetando v1 y creando la función..."
    empaquetar handler.js
    aws lambda create-function \
      --function-name "$FUNC" \
      --runtime "$RUNTIME" \
      --role "$ROLE_ARN" \
      --handler handler.handler \
      --timeout 15 \
      --zip-file fileb://funcion.zip \
      --environment "Variables={APP_VERSION=v1,FAIL_RATE=0,EXTRA_LATENCY_MS=0}" \
      --region "$REGION" >/dev/null
    aws lambda wait function-active-v2 --function-name "$FUNC" --region "$REGION"

    echo ">> Creando API HTTP (API Gateway v2) hacia la función..."
    API_ID="$(aws apigatewayv2 create-api \
      --name "${FUNC}-api" --protocol-type HTTP \
      --target "arn:aws:lambda:${REGION}:${ACCOUNT_ID}:function:${FUNC}:${ALIAS}" \
      --region "$REGION" --query ApiId --output text)"
    # Permiso para que la API invoque el alias.
    aws lambda add-permission \
      --function-name "${FUNC}:${ALIAS}" \
      --statement-id apigw-invoke \
      --action lambda:InvokeFunction \
      --principal apigateway.amazonaws.com \
      --source-arn "arn:aws:execute-api:${REGION}:${ACCOUNT_ID}:${API_ID}/*/*" \
      --region "$REGION" >/dev/null 2>&1 || true
    echo "$API_ID" > .api_id
    echo ">> Listo. Ejecuta: bash aws_lab.sh publicar-v1  y luego  bash aws_lab.sh canary 10"
    ;;

  publicar-v1)
    echo ">> Publicando Versión 1 (estándar) y apuntando el alias '${ALIAS}' a ella..."
    empaquetar handler.js
    aws lambda update-function-code --function-name "$FUNC" \
      --zip-file fileb://funcion.zip --region "$REGION" >/dev/null
    aws lambda wait function-updated-v2 --function-name "$FUNC" --region "$REGION"
    aws lambda update-function-configuration --function-name "$FUNC" \
      --environment "Variables={APP_VERSION=v1,FAIL_RATE=0,EXTRA_LATENCY_MS=0}" \
      --region "$REGION" >/dev/null
    aws lambda wait function-updated-v2 --function-name "$FUNC" --region "$REGION"
    V1="$(aws lambda publish-version --function-name "$FUNC" --region "$REGION" --query Version --output text)"
    echo "$V1" > .v1
    # Crear o mover el alias a v1 al 100%.
    if aws lambda get-alias --function-name "$FUNC" --name "$ALIAS" --region "$REGION" >/dev/null 2>&1; then
      aws lambda update-alias --function-name "$FUNC" --name "$ALIAS" \
        --function-version "$V1" --routing-config '{}' --region "$REGION" >/dev/null
    else
      aws lambda create-alias --function-name "$FUNC" --name "$ALIAS" \
        --function-version "$V1" --region "$REGION" >/dev/null
    fi
    echo ">> Versión 1 = $V1. El alias '${ALIAS}' sirve 100% v1."
    ;;

  publicar-v2)
    echo ">> Subiendo código v2 (con fallos + latencia) y publicando Versión 2..."
    # Reutiliza el mismo handler.js; la diferencia es la CONFIGURACIÓN de entorno.
    empaquetar handler.js
    aws lambda update-function-code --function-name "$FUNC" \
      --zip-file fileb://funcion.zip --region "$REGION" >/dev/null
    aws lambda wait function-updated-v2 --function-name "$FUNC" --region "$REGION"
    aws lambda update-function-configuration --function-name "$FUNC" \
      --environment "Variables={APP_VERSION=v2,FAIL_RATE=0.30,EXTRA_LATENCY_MS=400}" \
      --region "$REGION" >/dev/null
    aws lambda wait function-updated-v2 --function-name "$FUNC" --region "$REGION"
    V2="$(aws lambda publish-version --function-name "$FUNC" --region "$REGION" --query Version --output text)"
    echo "$V2" > .v2
    echo ">> Versión 2 (canaria) = $V2. Aún NO recibe tráfico; usa: bash aws_lab.sh canary 10"
    ;;

  canary)
    PESO="${2:?Indica el porcentaje de tráfico canario, p. ej. 10}"
    V1="$(cat .v1)"; V2="$(cat .v2)"
    FRAC="$(echo "scale=2; ${PESO}/100" | bc)"
    echo ">> Configurando canario: v1=${V1} (base) + ${PESO}% a v2=${V2}..."
    # El alias apunta a la versión base (v1) y deriva un % a la versión adicional (v2).
    aws lambda update-alias --function-name "$FUNC" --name "$ALIAS" \
      --function-version "$V1" \
      --routing-config "AdditionalVersionWeights={\"${V2}\"=${FRAC}}" \
      --region "$REGION" >/dev/null
    echo ">> Alias '${ALIAS}': ${PESO}% v2 / $((100-PESO))% v1."
    ;;

  promover)
    V2="$(cat .v2)"
    aws lambda update-alias --function-name "$FUNC" --name "$ALIAS" \
      --function-version "$V2" --routing-config '{}' --region "$REGION" >/dev/null
    echo ">> PROMOVIDO: alias '${ALIAS}' = 100% v2 (${V2})."
    ;;

  revertir)
    V1="$(cat .v1)"
    aws lambda update-alias --function-name "$FUNC" --name "$ALIAS" \
      --function-version "$V1" --routing-config '{}' --region "$REGION" >/dev/null
    echo ">> ROLLBACK: alias '${ALIAS}' = 100% v1 (${V1})."
    ;;

  estado)
    aws lambda get-alias --function-name "$FUNC" --name "$ALIAS" --region "$REGION" \
      --query '{VersionBase:FunctionVersion, Routing:RoutingConfig.AdditionalVersionWeights}' \
      --output table
    ;;

  url)
    API_ID="$(cat .api_id)"
    echo "https://${API_ID}.execute-api.${REGION}.amazonaws.com/ping"
    echo "(ruta por defecto \$default; puedes llamar cualquier path, p. ej. /ping)"
    ;;

  limpiar)
    API_ID="$(cat .api_id 2>/dev/null || true)"
    [ -n "$API_ID" ] && aws apigatewayv2 delete-api --api-id "$API_ID" --region "$REGION" || true
    aws lambda delete-function --function-name "$FUNC" --region "$REGION" || true
    rm -f funcion.zip .api_id .v1 .v2 handler.js
    echo ">> Recursos eliminados."
    ;;

  *)
    echo "Comandos: crear | publicar-v1 | publicar-v2 | canary <%> | promover | revertir | estado | url | limpiar"
    ;;
esac
