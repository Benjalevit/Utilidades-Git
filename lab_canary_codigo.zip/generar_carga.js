//  Envía N solicitudes a un endpoint (el de API Gateway que apunta al alias de
//  Lambda con routing ponderado) y mide, SEPARADO POR VERSIÓN:
//      - Nº de solicitudes atendidas por cada versión  (reparto real del canario)
//      - Tasa de error 5xx por versión
//      - Latencia p50 / p95 / máx por versión
//
//  La versión se identifica por la cabecera 'X-App-Version' que agrega la
//  función. Así el alumno ve qué hizo cada versión AUNQUE compartan el mismo
//  endpoint, que es justo el punto de un despliegue canario.
//
//  Uso:
//      node generar_carga.js <URL> [N] [CONCURRENCIA]
//  Ejemplos:
//      node generar_carga.js https://xxxx.execute-api.us-east-1.amazonaws.com/ping
//      node generar_carga.js https://xxxx.../ping 500 20
//
//  No requiere instalar nada: usa fetch nativo de Node 18+.

'use strict';

const URL          = process.argv[2];
const TOTAL        = parseInt(process.argv[3] || '300', 10);
const CONCURRENCIA = parseInt(process.argv[4] || '15', 10);

if (!URL) {
  console.error('Uso: node generar_carga.js <URL> [N_solicitudes] [concurrencia]');
  process.exit(1);
}

// Acumuladores por versión. 'desconocida' recoge respuestas sin cabecera.
const stats = {};
function bucket(v) {
  if (!stats[v]) stats[v] = { total: 0, exito: 0, error5xx: 0, otros: 0, latencias: [] };
  return stats[v];
}

async function unaSolicitud() {
  const t0 = Date.now();
  let version = 'desconocida';
  let status = 0;
  try {
    const res = await fetch(URL, { method: 'GET' });
    status = res.status;
    version = res.headers.get('x-app-version') || 'desconocida';
    // Consumir el cuerpo para cerrar la conexión limpiamente.
    await res.text();
  } catch (e) {
    status = 0; // error de red/timeout
  }
  const dt = Date.now() - t0;

  const b = bucket(version);
  b.total++;
  b.latencias.push(dt);
  if (status >= 200 && status < 400) b.exito++;
  else if (status >= 500 || status === 0) b.error5xx++;
  else b.otros++;
}

async function run() {
  console.log(`\nEnviando ${TOTAL} solicitudes a:\n  ${URL}`);
  console.log(`Concurrencia: ${CONCURRENCIA}\n`);
  let enviadas = 0;
  while (enviadas < TOTAL) {
    const lote = Math.min(CONCURRENCIA, TOTAL - enviadas);
    await Promise.all(Array.from({ length: lote }, unaSolicitud));
    enviadas += lote;
    process.stdout.write(`\r  progreso: ${enviadas}/${TOTAL}`);
  }
  console.log('\n');
  reportar();
}

function percentil(arr, p) {
  if (arr.length === 0) return 0;
  const orden = [...arr].sort((a, b) => a - b);
  const idx = Math.ceil((p / 100) * orden.length) - 1;
  return orden[Math.max(0, idx)];
}

function reportar() {
  const versiones = Object.keys(stats).sort();
  let totalGlobal = 0, errorGlobal = 0;

  console.log('='.repeat(72));
  console.log('RESULTADOS POR VERSIÓN');
  console.log('='.repeat(72));
  for (const v of versiones) {
    const b = stats[v];
    const tasaError = ((b.error5xx / b.total) * 100).toFixed(1);
    const reparto   = ((b.total / TOTAL) * 100).toFixed(1);
    totalGlobal += b.total;
    errorGlobal += b.error5xx;
    console.log(`
  Versión: ${v}
    Solicitudes atendidas : ${b.total}  (${reparto}% del tráfico)
    Éxito (2xx/3xx)       : ${b.exito}
    Errores 5xx / red     : ${b.error5xx}
    Tasa de error         : ${tasaError} %
    Latencia p50          : ${percentil(b.latencias, 50)} ms
    Latencia p95          : ${percentil(b.latencias, 95)} ms
    Latencia máx          : ${Math.max(...b.latencias)} ms`);
  }

  console.log('\n' + '-'.repeat(72));
  const tasaGlobal = ((errorGlobal / totalGlobal) * 100).toFixed(1);
  console.log(`  GLOBAL: ${totalGlobal} solicitudes · tasa de error total ${tasaGlobal} %`);
  console.log('-'.repeat(72));

  console.log('\nResumen CSV (versión,solicitudes,%trafico,tasa_error_%,p95_ms):');
  for (const v of versiones) {
    const b = stats[v];
    console.log(
      `  ${v},${b.total},${((b.total/TOTAL)*100).toFixed(1)},` +
      `${((b.error5xx/b.total)*100).toFixed(1)},${percentil(b.latencias,95)}`
    );
  }
  console.log('');
}

run();
