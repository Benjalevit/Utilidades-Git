//  Una sola función sirve como v1 (estándar) y v2 (canaria). El COMPORTAMIENTO
//  se controla por variables de entorno, de modo que publicas dos versiones de
//  la MISMA función con configuración distinta:
//
//    v1 (estándar):  APP_VERSION=v1  FAIL_RATE=0     EXTRA_LATENCY_MS=0
//    v2 (canaria) :  APP_VERSION=v2  FAIL_RATE=0.30  EXTRA_LATENCY_MS=400
//
//  La v2 simula una "mala versión": falla el 30% de las veces (HTTP 500) y
//  agrega 400 ms de latencia. El objetivo del laboratorio es DETECTAR ese
//  deterioro observando solo el tráfico canario y decidir revertir.
//
//  Devuelve siempre JSON e informa qué versión respondió, para que el
//  generador de carga pueda contar errores y medir latencia por versión.

'use strict';

const APP_VERSION      = process.env.APP_VERSION      || 'v1';
const FAIL_RATE        = parseFloat(process.env.FAIL_RATE || '0'); // entre 0 y 1
const EXTRA_LATENCY_MS = parseInt(process.env.EXTRA_LATENCY_MS || '0', 10);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

exports.handler = async (event) => {
  const inicio = Date.now();

  // Latencia extra simulada (solo afecta a la versión canaria si se configura).
  if (EXTRA_LATENCY_MS > 0) {
    await sleep(EXTRA_LATENCY_MS);
  }

  // Fallo simulado: devuelve 500 con probabilidad FAIL_RATE.
  if (Math.random() < FAIL_RATE) {
    return respuesta(500, {
      ok: false,
      version: APP_VERSION,
      error: 'Error simulado en la versión canaria',
      latencia_ms: Date.now() - inicio,
    });
  }

  // Respuesta exitosa.
  return respuesta(200, {
    ok: true,
    version: APP_VERSION,
    mensaje: `Hola desde ${APP_VERSION}`,
    latencia_ms: Date.now() - inicio,
  });
};

function respuesta(status, cuerpo) {
  return {
    statusCode: status,
    headers: {
      'Content-Type': 'application/json',
      'X-App-Version': cuerpo.version, // Cabecera propia para rastrear la versión también desde el cliente.
    },
    body: JSON.stringify(cuerpo),
  };
}
